"# -- coding: UTF-8 --"

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torchvision
from torchvision import transforms
import random

from model.Unet.SiamUNet_Diff import SiamUnet_diff
from model.Unet.UNet_CD import Unet
from model.CNet.C_Net import C_Net
from tools import utils_train, change_dataset_np, utils_train_ys

print("PyTorch Version: ", torch.__version__)
print("Torchvision Version: ", torchvision.__version__)

# Hyperparameters
num_epochs = 200
num_classes = 2
batch_size = 16
img_size = 256
start_epoch = 0
f_score = 0.0
val_acc = []
train_loss = []

base_lr = 0.0001
choice = 2
data = ['WHU', 'LEVIR', 'DSIFN', 'SYSU', 'CDD']
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
log_dir = None                                                                      # load checkpoint
name = 'CNet'

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
# 设置随机数种子
setup_seed(20)

print('Device:', device)
print('Dataset:', data[choice])
num_gpu = torch.cuda.device_count()
print('Number of GPUs Available:', num_gpu)

if data[choice] == 'LEVIR':
    train_pickle_file = '/root/autodl-tmp/LEVIR_CD/train'###png*3
    val_pickle_file = '/root/autodl-tmp/LEVIR_CD/val'
elif data[choice] == 'WHU':
    train_pickle_file = '/home/server05/桌面/Chen/Dataset/WHU/WHU_CD_manage/train'
    val_pickle_file = '/home/server05/桌面/Chen/Dataset/WHU/WHU_CD_manage/val'
elif data[choice] == 'DSIFN':
    train_pickle_file = '/root/autodl-tmp/DSIFN_512/train'
    val_pickle_file = '/root/autodl-tmp/DSIFN_512/val'
elif data[choice] == 'SYSU':
    train_pickle_file = '/home/server05/桌面/Chen/Dataset/SYSU/train'
    val_pickle_file = '/home/server05/桌面/Chen/Dataset/SYSU/val'
elif data[choice] == 'CDD':
    train_pickle_file = '/root/data_cdd/train'
    val_pickle_file = '/root/data_cdd/val'


data_transforms = {
    'train': transforms.Compose([
        transforms.Resize(img_size),
        transforms.CenterCrop(img_size),
        transforms.RandomGrayscale(p=0.2),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, saturation=0, hue=0),
        transforms.ToTensor(),
        # transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.255])
    ]),
    'val': transforms.Compose([
        transforms.Resize(img_size),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
        # transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.255])
    ]),
}

# Create training and validation datasets
train_dataset = change_dataset_np.ChangeDatasetNumpy(train_pickle_file, data_transforms['train'], data[choice])
val_dataset = change_dataset_np.ChangeDatasetNumpy(val_pickle_file, data_transforms['val'], data[choice])
image_datasets = {'train': train_dataset, 'val': val_dataset}

# Create training and validation dataloaders
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True)
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True)
dataloaders_dict = {'train': train_loader, 'val': val_loader}


# Initialize Model

UNet_mlstm = C_Net(nclass=2)     #SiamUN
# UNet_mlstm = Unet(input_nbr=6, label_nbr=2)     #SiamUN
# UNet_mlstm = SiamUnet_diff(input_nbr=3, label_nbr=2)
# UNet_mlstm = SiamUNet_Conv(input_nbr=3, label_nbr=2)
UNet_mlstm = UNet_mlstm.to(device)


weight_tensor = torch.FloatTensor(2)
weight_tensor[0] = 0.20
weight_tensor[1] = 0.80
criterion = nn.CrossEntropyLoss(weight_tensor)
criterion = criterion.to(device)


optimizer = optim.Adam(UNet_mlstm.parameters(), lr=base_lr)
# optimizer = optim.SGD(UNet_mlstm.parameters(), lr=base_lr, momentum=0.9)
sc_plt = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', patience=15, verbose=True)


def exist_log_dir(input):
    if input is not None:
        return True
    else:
        return False

if exist_log_dir(log_dir):
    path_checkpoint = log_dir
    checkpoint = torch.load(path_checkpoint)
    start_epoch = checkpoint['epoch']
    UNet_mlstm.load_state_dict(checkpoint['net'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    f_score = checkpoint['best_f_score']
    sc_plt.load_state_dict(checkpoint['lr_schedule'])
    val_acc = checkpoint['val_acc']
    train_loss = checkpoint['train_loss']
    print("载入模型成功！")

# train
utils_train_ys.train_model(UNet_mlstm, dataloaders_dict, criterion, optimizer, sc_plt, device, num_epochs, name, start_epoch, f_score, val_acc, train_loss, data[choice])





