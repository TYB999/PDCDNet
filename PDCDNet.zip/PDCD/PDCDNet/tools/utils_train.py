"# -- coding: UTF-8 --"
import os
import numpy as np
import torch
from matplotlib import pyplot as plt
import torch.nn.functional as F
from tqdm import tqdm
from tools.metrics import Metrics

def train_model(model, dataloaders, criterion, optimizer, sc_plt, device, num_epochs, name, start_epoch, f_score, val_acc, train_loss, dataset):
    best_acc = f_score
    # metrics = Metrics(range(2))

    for epoch in range(start_epoch, num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)
        metrics = Metrics(range(2))
        # print(metrics.fn)
        # Each epoch has a training and validation phase
        for phase in ['train', 'val']:            
            if phase == 'train':
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            # Iterate over data.
            for sample in tqdm(dataloaders[phase]):
                reference_img = sample['reference'].to(device)
                test_img = sample['test'].to(device)
                labels = (sample['label'] > 0).squeeze(1).type(torch.LongTensor).to(device)


                # zero the parameter gradients
                optimizer.zero_grad()

                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'): #train 可以计算梯度，val的时候不计算

                    reference_img = reference_img.unsqueeze(0)
                    test_img = test_img.unsqueeze(0)

                    image_input = torch.cat([reference_img, test_img], dim=0)               

                    outputs = model(image_input)

                    loss_seg = criterion(outputs, labels)

                    loss = loss_seg

                    # Calculate metric during evaluation
                    if phase == 'val':
                        # dice_value = seg_metrics.iou_segmentation(preds.squeeze(1).type(torch.LongTensor), (labels>0).type(torch.LongTensor))
                        # list_dice_val.append(dice_value.item())
                        for mask, output in zip(labels, outputs):
                            metrics.add(mask, output)

                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # statistics
                running_loss_seg = 0.0
                running_loss_seg += loss.item() * reference_img.size(0)


            epoch_loss_seg = running_loss_seg / len(dataloaders[phase].dataset)


            epoch_loss = epoch_loss_seg

            print('{} Loss_seg: {:.6f}'.format(phase, epoch_loss_seg))


            if phase == 'val':
                precision = metrics.get_precision()
                recall = metrics.get_recall()
                f_score = metrics.get_f_score()
                oa = metrics.get_oa()
                print('precision:{:.4f}, recall:{:.4f}, f_score:{:.4f}, oa:{:.4f}'.format(precision, recall, f_score, oa))
                sc_plt.step(f_score) #自适应学习率，调整学习率评价指标
    
            
            # Update Scheduler if training loss doesn't change for patience(2) epochs
            if phase == 'train':
                # sc_plt.step(epoch_loss)   #自适应学习率，调整学习率评价指标
                train_loss.append(epoch_loss)
                print('lr:{}'.format(optimizer.param_groups[0]['lr']))

            if phase == 'val':
                val_acc.append(f_score)
                if not os.path.exists('best_model/' + name + '/Tendency'):
                    os.makedirs('best_model/' + name + '/Tendency')
                x = np.arange(0, epoch + 1, 1)
                plt.figure()
                plt.plot(x, val_acc, 'r', label='val_f1')
                plt.savefig('best_model/' + name + '/Tendency' + '/val_f_score.png')
                plt.close()
                plt.figure()
                plt.plot(x, train_loss, 'r', label='train_loss')
                plt.savefig('best_model/' + name + '/Tendency' + '/train_loss.png')
                plt.close()

            # deep copy the model and save if accuracy is better
            if phase == 'val' and f_score > best_acc:
                best_acc = f_score
                if not os.path.exists('best_model/' + name + '/model'):
                    os.makedirs('best_model/' + name + '/model')
                best_checkpoint = 'best_model/' + name + '/model' + '/best_model_epoch{}_f_score{:.4f}.pth'.format(epoch, f_score)

                checkpoint = {
                    "net": model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    "epoch": epoch + 1,
                    "best_f_score": best_acc,
                    "lr_schedule": sc_plt.state_dict(),
                    "name": name,
                    "val_acc": val_acc,
                    "train_loss": train_loss,
                    "dataset": dataset}
                torch.save(checkpoint, best_checkpoint)

            if phase == 'val':
                checkpoint_new = {
                    "net": model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    "epoch": epoch + 1,
                    "best_f_score": best_acc,
                    "lr_schedule": sc_plt.state_dict(),
                    "name": name,
                    "val_acc": val_acc,
                    "train_loss": train_loss,
                    "dataset": dataset}
                new_checkpoint = 'best_model/' + name + '/model' + '/new_model.pth'
                torch.save(checkpoint_new, new_checkpoint)
                print('Best f_score: {:4f}'.format(best_acc))