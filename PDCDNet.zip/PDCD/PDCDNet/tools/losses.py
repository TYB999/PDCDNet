import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):

    def __init__(self, gamma=0, alpha=None, size_average=True):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        if isinstance(alpha, (float, int)): self.alpha = torch.Tensor([alpha, 1 - alpha])
        if isinstance(alpha, list): self.alpha = torch.Tensor(alpha)
        self.size_average = size_average

    def forward(self, input, target):
        if input.dim() > 2:
            input = input.view(input.size(0), input.size(1), -1)  # N,C,H,W => N,C,H*W
            input = input.transpose(1, 2)                         # N,C,H*W => N,H*W,C
            input = input.contiguous().view(-1, input.size(2))    # N,H*W,C => N*H*W,C
        target = target.view(-1, 1)

        logpt = F.log_softmax(input, dim=1)
        logpt = logpt.gather(1, target)
        logpt = logpt.view(-1)
        pt = logpt.exp()

        if self.alpha is not None:
            if self.alpha.type() != input.data.type():
                self.alpha = self.alpha.type_as(input.data)
            at = self.alpha.gather(0, target.data.view(-1))
            logpt = logpt * at

        loss = -1 * (1 - pt)**self.gamma * logpt
        if self.size_average: return loss.mean()
        else: return loss.sum()

        
class SoftLoss(nn.Module):

    def __init__(self, T = 1.5):
        super(SoftLoss, self).__init__()
        self.T = T

    def forward(self, predict, target):
        """
            Args:
                predict:(n, c, h, w)
                target:(n, c, h, w)
                weight (Tensor, optional): a manual rescaling weight given to each class.
                                           If given, has to be a Tensor of size "nclasses"
        """
        assert predict.dim() == 4
        assert target.dim() == 4
        assert predict.size(0) == target.size(0), "{0} vs {1} ".format(predict.size(0), target.size(0))
        assert predict.size(1) == target.size(1), "{0} vs {1} ".format(predict.size(1), target.size(1))
        assert predict.size(2) == target.size(2), "{0} vs {1} ".format(predict.size(2), target.size(2))
        assert predict.size(3) == target.size(3), "{0} vs {1} ".format(predict.size(3), target.size(3))

        predict = F.log_softmax(predict / self.T, dim=1)
        target = F.softmax(target / self.T, dim=1)

        loss = (self.T ** 2) * F.kl_div(predict, target, size_average=True)
        '''
        input (Tensor) – Tensor of arbitrary shape in log-probabilities.
        target (Tensor) – Tensor of the same shape as input. See log_target for the target’s interpretation.
        '''
        return loss


class MixedLoss(nn.Module):
    def __init__(self, critns, coeffs=1.0):
        super().__init__()
        self.critns = critns
        if isinstance(coeffs, float):
            coeffs = [coeffs] * len(critns)
        if len(coeffs) != len(critns):
            raise ValueError
        self.coeffs = coeffs

    def forward(self, pred, tar):
        loss = 0.0
        for critn, coeff in zip(self.critns, self.coeffs):
            loss += coeff * critn(pred, tar)
        return loss


class CombinedLoss(nn.Module):
    def __init__(self, critn, coeffs=1.0):
        super().__init__()
        self.critn = critn
        self.coeffs = coeffs

    def forward(self, preds, tar):
        if isinstance(self.coeffs, float):
            coeffs = [self.coeffs] * len(preds)
        else:
            coeffs = self.coeffs
        if len(coeffs) != len(preds):
            raise ValueError
        loss = 0.0
        for coeff, pred in zip(coeffs, preds):
            loss += coeff * self.critn(pred, tar)
        return loss


class CombinedLoss_DS(nn.Module):
    def __init__(self, critn_main, critn_aux, coeff_main=1.0, coeffs_aux=1.0, main_idx=0):
        super().__init__()
        self.critn_main = critn_main
        self.critn_aux = critn_aux
        self.coeff_main = coeff_main
        self.coeffs_aux = coeffs_aux
        self.main_idx = main_idx

    def forward(self, preds, tar, tar_aux=None):
        if tar_aux is None:
            tar_aux = tar

        pred_main = preds[self.main_idx]
        preds_aux = [pred for i, pred in enumerate(preds) if i != self.main_idx]

        if isinstance(self.coeffs_aux, float):
            coeffs_aux = [self.coeffs_aux] * len(preds_aux)
        else:
            coeffs_aux = self.coeffs_aux
        if len(coeffs_aux) != len(preds_aux):
            raise ValueError

        loss = self.critn_main(pred_main, tar)
        for coeff, pred in zip(coeffs_aux, preds_aux):
            loss += coeff * self.critn_aux(pred, tar_aux)
        return loss


# Refer to https://github.com/hubutui/DiceLoss-PyTorch/blob/master/loss.py
class DiceLoss(nn.Module):
    def __init__(self, smooth=1, p=2):
        super().__init__()
        self.smooth = smooth
        self.p = p

    def forward(self, pred, tar):
        pred, tar = pred.flatten(1), tar.flatten(1)
        prob = F.sigmoid(pred)

        num = (prob * tar).sum(1) + self.smooth
        den = (prob.pow(self.p) + tar.pow(self.p)).sum(1) + self.smooth

        loss = 1 - num / den

        return loss.mean()


class BCLoss(nn.Module):
    def __init__(self, margin=2.0):
        super().__init__()
        self.m = margin
        self.eps = 1e-4

    def forward(self, pred, tar):
        utar = 1 - tar
        n_u = utar.sum() + self.eps
        n_c = tar.sum() + self.eps
        loss = 0.5 * torch.sum(utar * torch.pow(pred, 2)) / n_u + \
               0.5 * torch.sum(tar * torch.pow(torch.clamp(self.m - pred, min=0.0), 2)) / n_c
        return loss

class BCL(nn.Module):
    """
    batch-balanced contrastive loss
    no-change，1
    change，-1
    """
    def __init__(self, margin=2.0):
        super(BCL, self).__init__()
        self.margin = margin

    def forward(self, distance, label):

        label[label==255] = 1
        mask = (label != 255).float()
        distance = distance * mask
        pos_num = torch.sum((label==1).float())+0.0001
        neg_num = torch.sum((label==-1).float())+0.0001

        loss_1 = torch.sum((1+label) / 2 * torch.pow(distance, 2)) /pos_num
        loss_2 = torch.sum((1-label) / 2 * mask *
            torch.pow(torch.clamp(self.margin - distance, min=0.0), 2)
        ) / neg_num
        loss = loss_1 + loss_2
        return loss
