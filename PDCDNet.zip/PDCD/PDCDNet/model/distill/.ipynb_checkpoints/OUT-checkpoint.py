import torch.nn as nn
import torch.nn.functional as F
import torch
from collections import OrderedDict

from model.EfficientNet.OUT import OUT as eff_OUT
from model.CNet.C_Net import C_Net as res_OUT
from model.loss import FeatureLoss


class SegmentationDistiller(nn.Module):
    """Base distiller for detectors.

    It typically consists of teacher_model and student_model.
    """

    def __init__(self, output_ch, teacher_pretrained=None,student_pretrained=None):

        super(SegmentationDistiller, self).__init__()

        self.teacher = res_OUT(output_ch)
        if teacher_pretrained is not None:
            self.init_weights_teacher(teacher_pretrained)
        else:
            print("teacher 模型未载入预训练权重")
        self.teacher.eval()

        self.student = eff_OUT(output_ch)
        if student_pretrained is not None:
            self.init_weights_student(student_pretrained)
        else:
            print("student 模型未载入预训练权重")

        self.distill_losses = FeatureLoss(1280,128)
        weight_tensor = torch.FloatTensor(2)
        weight_tensor[0] = 0.20
        weight_tensor[1] = 0.80
        criterion = nn.CrossEntropyLoss(weight_tensor)
        self.criterion = criterion


    def init_weights_teacher(self, path_checkpoint=None):
        """Load the pretrained model in teacher detector.

        Args:
            pretrained (str, optional): Path to pre-trained weights.
                Defaults to None.
        """
        checkpoint = torch.load(path_checkpoint)
        self.teacher.load_state_dict(checkpoint['net'])
        print("载入teacher模型成功！")
       
    def init_weights_student(self, path_checkpoint=None):
        """Load the pretrained model in teacher detector.

        Args:
            pretrained (str, optional): Path to pre-trained weights.
                Defaults to None.
        """
        checkpoint = torch.load(path_checkpoint)
        self.student.load_state_dict(checkpoint['net'])
        print("载入student模型成功！")

    def forward(self, img, label=None):
        if self.training:
            with torch.no_grad():
                self.teacher.eval()
                fea_t = self.teacher.extract_feature(img)
                logit_t = self.teacher.decoder_foward(fea_t)

            student_feat = self.student.extract_feature(img)
            logit_s = self.student.decoder_foward(student_feat)
            losses = self.criterion(logit_s, label)


            distill_loss = self.distill_losses(student_feat, fea_t.detach())

            N, C, H, W = logit_s.shape
            softmax_pred_T = F.softmax(logit_t.view(-1, W * H) / 4, dim=1)
            logsoftmax = torch.nn.LogSoftmax(dim=1)
            loss = torch.sum(softmax_pred_T *
                             logsoftmax(logit_t.view(-1, W * H) / 4) -
                             softmax_pred_T *
                             logsoftmax(logit_s.view(-1, W * H) / 4)) * (
                           4 ** 2)

            loss_logit = 3 * loss / (C * N)

            total_loss = losses + loss_logit + distill_loss

            return logit_s, total_loss

        else:
            student_feat = self.student.extract_feature(img)
            logit_s = self.student.decoder_foward(student_feat)

            return logit_s, None