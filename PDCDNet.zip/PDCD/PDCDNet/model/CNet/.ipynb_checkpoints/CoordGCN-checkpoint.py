import torch
import torch.nn as nn
import torch.nn.modules.conv as conv


class AddCoords(nn.Module):
    def __init__(self, rank=2, with_r=False, use_cuda=True):
        super(AddCoords, self).__init__()
        self.rank = rank
        self.with_r = with_r
        self.use_cuda = use_cuda

    def forward(self, input_tensor):
        """
        :param input_tensor: shape (N, C_in, H, W)
        :return:
        """

        if self.rank == 2:
            batch_size_shape, channel_in_shape, dim_y, dim_x = input_tensor.shape
            xx_ones = torch.ones([1, 1, 1, dim_x], dtype=torch.int32)
            yy_ones = torch.ones([1, 1, 1, dim_y], dtype=torch.int32)

            xx_range = torch.arange(dim_y, dtype=torch.int32)
            yy_range = torch.arange(dim_x, dtype=torch.int32)
            xx_range = xx_range[None, None, :, None]
            yy_range = yy_range[None, None, :, None]

            xx_channel = torch.matmul(xx_range, xx_ones)
            yy_channel = torch.matmul(yy_range, yy_ones)


            # transpose y
            yy_channel = yy_channel.permute(0, 1, 3, 2)

            xx_channel = xx_channel.float() / (dim_y - 1)
            yy_channel = yy_channel.float() / (dim_x - 1)

            xx_channel = xx_channel * 2 - 1
            yy_channel = yy_channel * 2 - 1

            xx_channel = xx_channel.repeat(batch_size_shape, 1, 1, 1)
            yy_channel = yy_channel.repeat(batch_size_shape, 1, 1, 1)

            if torch.cuda.is_available and self.use_cuda:
                input_tensor = input_tensor.cuda()
                xx_channel = xx_channel.cuda()
                yy_channel = yy_channel.cuda()
            out_x = torch.cat([input_tensor, xx_channel], dim=1)
            out_y = torch.cat([input_tensor, yy_channel], dim=1)

        return out_x, out_y


class CoordGCN(nn.Module):
    def __init__(self, in_dim, out_dim, kernel_size, with_r=False):
        super(CoordGCN, self).__init__()

        self.addcoords = AddCoords(2, with_r, use_cuda=True)

        pad0 = int((kernel_size[0] - 1) / 2)
        pad1 = int((kernel_size[1] - 1) / 2)
        # 如果设置pad=(kernel_size-1)/2,则运算后，宽度和高度不变
        # kernel size had better be odd number so as to avoid alignment error
        self.conv_1 = nn.Conv2d(in_dim+1, out_dim, kernel_size=(kernel_size[0], 1),
                                padding=(pad0, 0), stride=2)
        self.conv_1_l = nn.Conv2d(out_dim+1, out_dim, kernel_size=(1, kernel_size[0]),
                                  padding=(0, pad0))
        self.conv_2 = nn.Conv2d(out_dim+1, out_dim, kernel_size=(kernel_size[1], 1),
                                padding=(pad1, 0))
        self.conv_2_l = nn.Conv2d(in_dim+1, out_dim, kernel_size=(1, kernel_size[1]),
                                  padding=(0, pad1), stride=2)

    def forward(self, input_tensor):

        x, y = self.addcoords(input_tensor)
        x = self.conv_1(x)
        y = self.conv_2_l(y)

        x_i, x_j = self.addcoords(x)
        y_i, y_j = self.addcoords(y)

        x = self.conv_1_l(x_j)
        y = self.conv_2(y_i)
        out = x + y
        return out


if __name__ == '__main__':
    net = CoordGCN(128, [5, 7])
    print(net)