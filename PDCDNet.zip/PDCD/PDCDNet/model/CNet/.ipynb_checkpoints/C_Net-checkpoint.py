import torch
from torch import nn
import torch.nn.functional as F
from .Res_Net import resnet34
from .CoordGCN import CoordGCN
from .global_local import global_local

in_channels = [128, 256, 512]

####################################################把所有resnet18改为50

class C_Net(nn.Module):
    def __init__(self, nclass):
        super(C_Net, self).__init__()
        self.nclass = nclass
        self.ResNet = resnet34()

        self.CoordGCN1 = CoordGCN(64, in_channels[0], kernel_size=[3, 3])
        self.CoordGCN2 = CoordGCN(in_channels[0], in_channels[1], kernel_size=[5, 5])
        self.CoordGCN3 = CoordGCN(in_channels[1], in_channels[2], kernel_size=[7, 7])

        self.global_local1 = global_local(in_channels[0])
        self.global_local2 = global_local(in_channels[1])
        self.global_local3 = global_local(in_channels[2])

        self.conv = nn.Sequential(nn.Conv2d(6, 64, kernel_size=7, bias=False, stride=2, padding=3),##########3-6
                                  nn.BatchNorm2d(64),
                                  nn.ReLU(inplace=True)
                                  )

        self.conv1 = nn.Sequential(nn.Conv2d(in_channels[0], nclass, kernel_size=1, bias=False),
                                   nn.BatchNorm2d(nclass),
                                   nn.ReLU(inplace=True)
                                   )
        self.conv2 = nn.Sequential(nn.Conv2d(in_channels[1], in_channels[0], kernel_size=1, bias=False),
                                   nn.BatchNorm2d(in_channels[0]),
                                   nn.ReLU(inplace=True)
                                   )
        self.conv3 = nn.Sequential(nn.Conv2d(in_channels[2], in_channels[1], kernel_size=1, bias=False),
                                   nn.BatchNorm2d(in_channels[1]),
                                   nn.ReLU(inplace=True)
                                   )

    def forward(self, x): 
        x1 = self.extract_feature(x)
        out = self.decoder_foward(x1)
        return out
    
    def extract_feature(self, x):
        x1 = x[0]##########
        x2 = x[1]############
        x = torch.cat((x1,x2),dim=1)#########此处加入了三行代码，用于在前向传播时将两张图片合并
        X, residual1, residual2, residual3 = self.ResNet(x)
        Coord = self.conv(x)

        Coord1 = self.CoordGCN1(Coord)
        Coord2 = self.CoordGCN2(Coord1)
        Coord3 = self.CoordGCN3(Coord2)
        
        x3 = Coord3+residual3
        x3 = self.global_local3(x3)
        x3 = self.conv3(x3)
        x3 = F.upsample_bilinear(x3, residual2.size()[2:])

        x2 = x3+residual2+Coord2
        x2 = self.global_local2(x2)
        x2 = self.conv2(x2)
        x2 = F.upsample_bilinear(x2, residual1.size()[2:])
        x1 = x2 + residual1 + Coord1

        return x1
        
    def decoder_foward(self, x1):
        # X, residual1, residual2, residual3 = self.ResNet(x)
        x1 = self.global_local1(x1)
        x1 = self.conv1(x1)
        out = F.upsample_bilinear(x1, (16, 6, 256, 256)[2:])
        return out


if __name__ == '__main__':
    net = global_local(6)
    total = sum([param.nelement() for param in net.parameters()])
    print("Number of parameter: %.2fM" % (total / 1e6))




