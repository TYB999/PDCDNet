import torch
import torch.nn as nn
from torch.nn import functional as F
from .Functions import *


class global_information(nn.Module):
    def __init__(self, in_channels, mlp_ratio=4., drop=0., layer_scale_init_value=1e-5, drop_path=0., norm_layer=GroupNorm):  # act_layer=nn.GELU,
        super(global_information, self).__init__()
        self.dw = DWConv(in_channels, in_channels, kernel_size=3, stride=1)
        self.linear = nn.Linear(in_channels, in_channels)  # learnable position embedding

        self.norm1 = norm_layer(in_channels)
        self.norm2 = norm_layer(in_channels)

        mlp_hidden_dim = int(in_channels * mlp_ratio)
        self.mlp = Mlp(in_features=in_channels, hidden_features=mlp_hidden_dim, act_layer=nn.ReLU,
                       drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. \
            else nn.Identity()

        self.layer_scale_1 = nn.Parameter(
                layer_scale_init_value * torch.ones((in_channels)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(
                layer_scale_init_value * torch.ones((in_channels)), requires_grad=True)

    def forward(self, x):
        x1 = self.drop_path(self.layer_scale_1.unsqueeze(-1).unsqueeze(-1) * self.dw(self.norm1(x)))
        x2 = self.drop_path(self.layer_scale_2.unsqueeze(-1).unsqueeze(-1) * self.mlp(self.norm2(x)))
        out = x1+x2
        return out


class local_information(nn.Module):
    def __init__(self, in_channels, num_codes):
        super(local_information, self).__init__()

        self.conv1 = ConvBlock(in_channels=in_channels, out_channels=in_channels)

        self.LVC = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, bias=False, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            Encoding(in_channels=in_channels, num_codes=64),
            nn.BatchNorm1d(num_codes),
            nn.ReLU(inplace=True),
            Mean(dim=1))
        self.fc = nn.Sequential(nn.Linear(in_channels, in_channels), nn.Sigmoid())

    def forward(self, x):
        x = self.conv1(x)
        en = self.LVC(x)
        gam = self.fc(en)
        b, in_channels, _, _ = x.size()
        y = gam.view(b, in_channels, 1, 1)
        x = F.relu_(x + x * y)
        return x


class global_local(nn.Module):
    def __init__(self, in_channels):
        super(global_local, self).__init__()

        self.global_information = global_information(in_channels)
        self.local_information = local_information(in_channels, num_codes=64)

    def forward(self, x):
        x1 = self.global_information(x)
        x2 = self.local_information(x)
        out = x1+x2
        return out


if __name__ == '__main__':
    net = global_local(128)
    print(net)
    total = sum([param.nelement() for param in net.parameters()])
    print("Number of parameter: %.2fM" % (total / 1e6))

