import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.modules.padding import ReplicationPad2d

class Decoder(nn.Module):
    """SiamUnet_conc segmentation network."""

    def __init__(self, input_nbr, label_nbr):
        super(Decoder, self).__init__()
        self.input_nbr = input_nbr
        self.label_nbr = label_nbr
        self.Conv1 = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(input_nbr, 640, kernel_size=9, stride=1, padding=4, bias=True),
            nn.BatchNorm2d(640),
            nn.ReLU(inplace=True),
        )

        self.Conv2 = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(640, 320, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(320),
            nn.ReLU(inplace=True),
        )

        self.Conv3 = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(320, 160, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(160),
            nn.ReLU(inplace=True),
        )

        self.Conv4 = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(160, 80, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(80),
            nn.ReLU(inplace=True),
        )
        self.Conv5 = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(80, 40, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(40),
            nn.ReLU(inplace=True)
        )
        self.Conv6 = nn.Sequential(
            nn.Conv2d(40, 20, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(20),
            nn.ReLU(inplace=True)
        )
        self.Conv7 = nn.Sequential(
            nn.Conv2d(20, 10, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(10),
            nn.ReLU(inplace=True)
        )
        self.Last_Conv = nn.Conv2d(10, label_nbr, kernel_size=9, stride=1, padding=4)


    def forward(self, x):
        input = x

        # x  = F.pad(x, (0,self.patch_size - input.size(3), 0, self.patch_size - input.size(2)))
        """Forward method."""
        x = self.Conv1(x)
        x = self.Conv2(x)
        x = self.Conv3(x)
        x = self.Conv4(x)
        x = self.Conv5(x)
        x = self.Conv6(x)
        x = self.Conv7(x)

        output = self.Last_Conv(x)

        return output

if __name__ == '__main__':
    x = torch.randn(1,1280,8,8)
    model = Decoder(1280, 2)
    y = model(x)
    print(y.size())