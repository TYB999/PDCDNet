import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torch.nn as nn

from model.EfficientNet.Decoder import Decoder
from model.EfficientNet.Encoder import efficientnet_b0


class OUT(nn.Module):
    def __init__(self, output_ch):
        super(OUT, self).__init__()
        self.output_ch = output_ch
        self.Encoder = efficientnet_b0(self.output_ch)
        self.Decoder = Decoder(1280,self.output_ch)

    # def forward(self, input):
    #     X = input[0]
    #     Y = input[1]
    #     x = torch.concat((X,Y),dim=1)
    #     Encoder_Feature = self.Encoder(x)
    #     output = self.Decoder(Encoder_Feature)
    #
    #     return output

    def forward(self, input):
        Encoder_Feature = self.extract_feature(input)
        output = self.decoder_foward(Encoder_Feature)

        return output

    def extract_feature(self, input):
        # print(input.shape)
        X = input[0]
        Y = input[1]
        x = torch.concat((X,Y),dim=1)
        Encoder_Feature = self.Encoder(x)

        return Encoder_Feature

    def decoder_foward(self, Encoder_Feature):
        output = self.Decoder(Encoder_Feature)

        return output
